package unimelb.bitbox;
import org.kohsuke.args4j.Option;

import unimelb.bitbox.util.HostPort;

public class CmdLineArgs {
	
	@Option(required = true, name = "-c", aliases = {"--command"}, usage = "Command name")
	private String command;
	
	@Option(required = true, name = "-s", aliases = {"--server"}, usage = "Server address")
	private String server;
	
	@Option(required = false, name = "-i", aliases = {"--identity"}, usage = "Identity")
	private String identity = null;
	
	@Option(required = false, name = "-p", aliases = {"--peer"}, usage = "Peer address")
	private String peer = null;
	
	public HostPort getServer() {
		return new HostPort(server);
	}
	
	public String getCommand() {
		return command;
	}
	
	public String getIdentity() {
		return identity;
	}
}

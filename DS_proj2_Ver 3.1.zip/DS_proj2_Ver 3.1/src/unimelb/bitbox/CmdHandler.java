package unimelb.bitbox;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;


import unimelb.bitbox.util.Configuration;
import unimelb.bitbox.util.Document;

public class CmdHandler extends Thread {
	private ServerSocket listeningSocket = null;
	private ServerMain sm;
	private Socket socket = null;
	String keys[];

	public CmdHandler(ServerMain sm) {
		int clientPort = Integer.parseInt(Configuration.getConfigurationValue("clientPort"));
		keys = Configuration.getConfigurationValue("authorized_keys").split(",");
		this.sm = sm;
		try {
			// Create a server socket listening on ports get from configuration
			listeningSocket = new ServerSocket(clientPort);
			System.out.println("Server listening on port " + clientPort + " for a command");
			// Listen for incoming connections for ever
			start();
		} catch (SocketException ex) {
			ex.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		// Accept an incoming client connection request
		try {
			while (true) {
				socket = listeningSocket.accept();
				String msg;
				// Output and Input Stream
				BufferedReader In = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
				BufferedWriter Out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
				msg = In.readLine();
				if (msg != null) {
					if (Document.parse(msg).get("command").equals("AUTH_REQUEST")) {
						String publicKey = null;
						System.out.println("Authorisation request received.");
						for (String key : keys) {
							if (key.split(" ")[2].equals(Document.parse(msg).get("identity"))) {
								publicKey = key.split(" ")[1];
								break;
							}
						}
						Document Doc = new Document();
						if (publicKey != null) {
							KeyGenerator keyGen = KeyGenerator.getInstance("AES");
							SecureRandom random = new SecureRandom();
							keyGen.init(128, random);
							SecretKey aesKey = keyGen.generateKey();
							try {
					            byte[] byte_pk= Base64.getDecoder().decode(publicKey); 
								KeyFactory keyFactory = KeyFactory.getInstance("RSA");
								X509EncodedKeySpec keySpec= new X509EncodedKeySpec(byte_pk);
								RSAPublicKey pk_spec= (RSAPublicKey) keyFactory.generatePublic(keySpec); 
								Cipher cipher = Cipher.getInstance("RSA");
								cipher.init(Cipher.WRAP_MODE, pk_spec);
								byte[] encrypted = cipher.wrap(aesKey);
								String encrptedAES = Base64.getEncoder().encodeToString(encrypted);
								Doc.append("AES", encrptedAES);
								Doc.append("status","true");
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						} else {
							Doc.append("status", "false");
							Doc.append("message", "publickey not found");
						}
						Doc.append("command", "AUTH_RESPONSE");
						Out.write(Doc.toJson() + "\n");
						Out.flush();
						System.out.println("Authorisation response sent.");
					} else {
						System.out.println("Invalid request received.");
					}
					socket.close();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

package unimelb.bitbox;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;

import unimelb.bitbox.util.Document;

public class CmdHandler extends Thread{
	private ServerSocket listeningSocket = null;
	private ServerMain sm;
	private Socket socket = null;
	
	public CmdHandler(ServerMain sm, int port) {
		this.sm = sm;
		try {
			// Create a server socket listening on ports get from configuration
			listeningSocket = new ServerSocket(port);
			System.out.println("Server listening on port " + port + " for a command");
			// Listen for incoming connections for ever
			start();
		} catch (SocketException ex) {
			ex.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} 
	}
	
	public void run() {
			// Accept an incoming client connection request
			try {
				while (true) {
				socket = listeningSocket.accept();
				String msg;
				// Output and Input Stream
				BufferedReader In = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
				BufferedWriter Out = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
				msg = In.readLine();
				if (msg != null) {
					if (Document.parse(msg).get("command").equals("AUTH_REQUEST")) {
						System.out.println("Authorisation request received.");
						Document Doc = new Document();
						Doc.append("command", "AUTH_RESPONSE");
						Doc.append("message", "Testing");
						Out.write(Doc.toJson() + "\n");
						Out.flush();
						System.out.println("Authorisation response sent.");
					} else {
						System.out.println("Invalid request received.");
					}
					socket.close();
				}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
	}
}
